# WhatsApp NDIS Bot

A deployable starter bot for WhatsApp Cloud API.

## What it does
- verifies your Meta webhook
- receives incoming WhatsApp messages
- replies automatically
- collects NDIS enquiry leads
- saves leads into a JSON file

## Bot flow
Main menu:
1. New client enquiry
2. Services we offer
3. Book a callback

## Files
- `app.py` - main Flask app
- `requirements.txt` - Python packages
- `render.yaml` - Render deployment config
- `.env.example` - environment variables example

## Deploy on Render
1. Create a new GitHub repo
2. Upload these files
3. Create a new Web Service on Render
4. Add environment variables:
   - `VERIFY_TOKEN`
   - `WHATSAPP_TOKEN`
   - `PHONE_NUMBER_ID`
   - `GRAPH_API_VERSION`
5. Deploy
6. Copy your Render URL, e.g.:
   `https://your-app.onrender.com/webhook`

## Connect to Meta WhatsApp Cloud API
In your Meta app:
- set callback URL to your `/webhook`
- set verify token to the same `VERIFY_TOKEN`
- subscribe to WhatsApp webhook fields

## Run locally
```bash
pip install -r requirements.txt
python app.py
```

## Test locally with ngrok
```bash
ngrok http 5000
```

Then use:
- webhook URL: `https://your-ngrok-url/webhook`

## Important note
This starter bot uses in-memory conversation state and a local JSON file.
For production, upgrade to:
- PostgreSQL / MySQL / Firebase
- Redis for session state
- proper admin dashboard
- staff notifications
- secure logging
