import os
import json
from datetime import datetime
from flask import Flask, request, jsonify
import requests

app = Flask(__name__)

VERIFY_TOKEN = os.getenv("VERIFY_TOKEN", "change-me")
WHATSAPP_TOKEN = os.getenv("WHATSAPP_TOKEN", "")
PHONE_NUMBER_ID = os.getenv("PHONE_NUMBER_ID", "")
GRAPH_API_VERSION = os.getenv("GRAPH_API_VERSION", "v23.0")
LEADS_FILE = os.getenv("LEADS_FILE", "ndis_whatsapp_leads.json")

# Simple in-memory conversation state
# For production, replace with Redis / database
user_states = {}

WELCOME_TEXT = (
    "Hi 👋 Welcome to our NDIS support service.\n\n"
    "Reply with one option:\n"
    "1. New client enquiry\n"
    "2. Services we offer\n"
    "3. Book a callback"
)

SERVICES_TEXT = (
    "Our NDIS support services may include:\n"
    "- Daily living support\n"
    "- Community access\n"
    "- Personal care\n"
    "- Domestic assistance\n"
    "- Transport support\n\n"
    "Reply 1 to make a new enquiry or 3 to book a callback."
)


def load_leads():
    if not os.path.exists(LEADS_FILE):
        return []
    try:
        with open(LEADS_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return []


def save_lead(lead):
    leads = load_leads()
    leads.append(lead)
    with open(LEADS_FILE, "w", encoding="utf-8") as f:
        json.dump(leads, f, indent=2, ensure_ascii=False)


def send_whatsapp_message(to_number: str, body: str):
    if not WHATSAPP_TOKEN or not PHONE_NUMBER_ID:
        print("Missing WHATSAPP_TOKEN or PHONE_NUMBER_ID")
        return

    url = f"https://graph.facebook.com/{GRAPH_API_VERSION}/{PHONE_NUMBER_ID}/messages"
    headers = {
        "Authorization": f"Bearer {WHATSAPP_TOKEN}",
        "Content-Type": "application/json",
    }
    payload = {
        "messaging_product": "whatsapp",
        "to": to_number,
        "type": "text",
        "text": {"body": body},
    }
    response = requests.post(url, headers=headers, json=payload, timeout=30)
    print("Send status:", response.status_code, response.text)


def get_message_text(value: dict):
    messages = value.get("messages", [])
    if not messages:
        return None, None

    message = messages[0]
    from_number = message.get("from")
    msg_type = message.get("type")

    if msg_type == "text":
        return from_number, message.get("text", {}).get("body", "").strip()

    if msg_type == "interactive":
        interactive = message.get("interactive", {})
        if interactive.get("type") == "button_reply":
            return from_number, interactive.get("button_reply", {}).get("title", "").strip()
        if interactive.get("type") == "list_reply":
            return from_number, interactive.get("list_reply", {}).get("title", "").strip()

    return from_number, None


@app.route("/", methods=["GET"])
def home():
    return jsonify({
        "status": "ok",
        "message": "WhatsApp NDIS bot is running"
    })


@app.route("/webhook", methods=["GET"])
def verify_webhook():
    mode = request.args.get("hub.mode")
    token = request.args.get("hub.verify_token")
    challenge = request.args.get("hub.challenge")

    if mode == "subscribe" and token == VERIFY_TOKEN:
        return challenge, 200
    return "Verification failed", 403


@app.route("/webhook", methods=["POST"])
def receive_webhook():
    data = request.get_json(silent=True) or {}
    print("Webhook payload:", json.dumps(data, indent=2))

    try:
        for entry in data.get("entry", []):
            for change in entry.get("changes", []):
                value = change.get("value", {})
                from_number, text = get_message_text(value)

                if not from_number:
                    continue

                handle_user_message(from_number, text)
    except Exception as e:
        print("Error handling webhook:", str(e))

    return "EVENT_RECEIVED", 200


def handle_user_message(from_number: str, text: str | None):
    state = user_states.get(from_number, {"step": "start", "lead": {}})

    if not text:
        send_whatsapp_message(
            from_number,
            "Sorry, I can currently handle text messages only.\n\n" + WELCOME_TEXT
        )
        return

    clean = text.strip()

    if clean.lower() in {"hi", "hello", "hey", "start", "menu"}:
        user_states[from_number] = {"step": "menu", "lead": {}}
        send_whatsapp_message(from_number, WELCOME_TEXT)
        return

    # Menu actions
    if clean == "1" and state["step"] in {"start", "menu"}:
        state["step"] = "ask_name"
        user_states[from_number] = state
        send_whatsapp_message(from_number, "Please send your full name.")
        return

    if clean == "2":
        user_states[from_number] = {"step": "menu", "lead": {}}
        send_whatsapp_message(from_number, SERVICES_TEXT)
        return

    if clean == "3" and state["step"] in {"start", "menu"}:
        state["step"] = "ask_callback_name"
        user_states[from_number] = state
        send_whatsapp_message(from_number, "Sure. Please send your full name for the callback booking.")
        return

    # Callback flow
    if state["step"] == "ask_callback_name":
        state["lead"]["full_name"] = clean
        state["step"] = "ask_callback_time"
        user_states[from_number] = state
        send_whatsapp_message(from_number, "What day/time suits you for a callback?")
        return

    if state["step"] == "ask_callback_time":
        state["lead"]["callback_time"] = clean
        state["lead"]["phone"] = from_number
        state["lead"]["type"] = "callback_request"
        state["lead"]["created_at"] = datetime.utcnow().isoformat()
        save_lead(state["lead"])
        user_states[from_number] = {"step": "menu", "lead": {}}
        send_whatsapp_message(
            from_number,
            "Thank you. Your callback request has been saved. Our team will contact you soon.\n\nReply MENU to return to the main menu."
        )
        return

    # Enquiry flow
    if state["step"] == "ask_name":
        state["lead"]["full_name"] = clean
        state["step"] = "ask_suburb"
        user_states[from_number] = state
        send_whatsapp_message(from_number, "Which suburb are you located in?")
        return

    if state["step"] == "ask_suburb":
        state["lead"]["suburb"] = clean
        state["step"] = "ask_support"
        user_states[from_number] = state
        send_whatsapp_message(from_number, "What support do you need? Example: personal care, community access, domestic assistance.")
        return

    if state["step"] == "ask_support":
        state["lead"]["support_needed"] = clean
        state["step"] = "ask_funding"
        user_states[from_number] = state
        send_whatsapp_message(from_number, "What is your funding type? Reply with: self-managed, plan-managed, NDIA-managed, or unknown.")
        return

    if state["step"] == "ask_funding":
        state["lead"]["funding_type"] = clean
        state["step"] = "ask_email"
        user_states[from_number] = state
        send_whatsapp_message(from_number, "Please send your email address.")
        return

    if state["step"] == "ask_email":
        state["lead"]["email"] = clean
        state["lead"]["phone"] = from_number
        state["lead"]["type"] = "new_client_enquiry"
        state["lead"]["created_at"] = datetime.utcnow().isoformat()
        save_lead(state["lead"])

        user_states[from_number] = {"step": "menu", "lead": {}}
        send_whatsapp_message(
            from_number,
            "Thank you. Your enquiry has been saved and our team will contact you soon.\n\nReply MENU to return to the main menu."
        )
        return

    send_whatsapp_message(from_number, WELCOME_TEXT)


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.getenv("PORT", "5000")))
